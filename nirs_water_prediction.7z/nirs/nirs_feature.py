
from utils import getDataIndex

def pca(parms):
    from sklearn.decomposition import PCA

    return PCA(**parms)
def plsr(parms):
    from sklearn.cross_decomposition import PLSRegression
    return PLSRegression(**parms)
def mds(params):
    from sklearn.manifold import MDS

    return MDS(**params)

def none(params):
    return None



class FeatureSelection:
    def __init__(self, method='none',index_set = None, **kwargs):
        self.method =  method.lower()
        self.params = kwargs
        self.index = None
        if index_set == None:
            self.index_set = {"cars"}
        else:
            self.index_set = index_set
    def fit(self, X,y):
        m = self.method
        pls = None
        if m in globals().keys():
            pls = globals()[m](self.params)
        elif m in self.index_set:
            self.index = self.params["index"]

        else:
            raise "not support feature method"

        self.pls = pls
        if pls != None:
            pls.fit(X, y)



    def transform(self, X, y):

        item = self.method
        method = self.pls
        if item == 'none':
            pass
        elif self.pls == None and self.index != None:
            X = getDataIndex(X, self.index)
        elif   hasattr(method, "transform") and callable(getattr(method, "transform")):
            X,y = self.pls.transform(X,y)
        elif  hasattr(method, "fit_transform") and callable(getattr(method, "fit_transform")):
            X,y = self.pls.fit_transform(X,y)
        else:
             raise "找不到"

        return X,y


