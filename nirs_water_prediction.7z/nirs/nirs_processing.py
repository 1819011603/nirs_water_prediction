import numpy as np
from scipy import signal
from scipy.signal import find_peaks, peak_widths
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler



def msc(data):
    """"
    data 横轴方向表示重复测量的数据，纵轴方向表示波段数量
    """
    # 计算平均光谱，实际就是x值
    s_mean = np.mean(data, axis=1)

    # 行列数
    r, c = data.shape

    # 创建一个单位矩阵
    msc_x = np.ones((r, c))

    # 遍历各列，实际是各重复测量
    for i in range(c):

        # y值
        y = data[:, i]

        # 计算光谱回归系数Ki,Bi
        lin = LinearRegression()
        lin.fit(s_mean.reshape(-1, 1), y.reshape(-1, 1))
        k = lin.coef_
        b = lin.intercept_

        msc_x[:, i] = (y - b) / k

    return msc_x



def mas(X, window_size=11):
    # 使用 numpy 的 convolve 函数进行平滑处理
    weights = np.ones(window_size) / window_size
    X_mas = np.apply_along_axis(lambda m: np.convolve(m, weights, mode='same'), axis=1, arr=X)
    return X_mas

# def snv(X):
#     # 对每个光谱进行标准正态变换
#     X_snv = (X - X.mean(axis=1)[:, np.newaxis]) / X.std(axis=1)[:, np.newaxis]
#     return X_snv
def snv(data):
    scaler = StandardScaler(with_mean=True, with_std=True)
    return scaler.fit_transform(data)

def boc(X):
    # 对每个光谱进行基线偏移校正
    X_boc = X - X.min(axis=1)[:, np.newaxis]
    # 寻找谷底位置
    valley_indices, _ = find_peaks(-X_boc, prominence=0.1)
    # 寻找谷底位置左右两侧的峰顶
    left_indices, right_indices = [], []
    for i in valley_indices:
        left, right = peak_widths(X_boc[i-10:i+10], [np.argmax(X_boc[i-10:i+10])])[2:]
        left_indices.append(i-10+int(left))
        right_indices.append(i-10+int(right))
    # 使用三次样条插值平滑基线
    for i in range(X_boc.shape[0]):
        X_boc[i, left_indices[i]:right_indices[i]] = np.interp(np.arange(left_indices[i], right_indices[i]),
                                                               [left_indices[i], right_indices[i]],
                                                               [X_boc[i, left_indices[i]], X_boc[i, right_indices[i]]])
    return X_boc

from scipy.signal import savgol_filter

def boc(data, window_size=101, polyorder=3):
    # Apply Savitzky-Golay filter to smooth the spectra
    smoothed_data = savgol_filter(data, window_size, polyorder, axis=1)

    # Calculate the baseline for each spectrum as the median value
    baseline = np.median(smoothed_data, axis=1)

    # Subtract the baseline from each spectrum
    corrected_data = data - np.expand_dims(baseline, axis=1)

    return corrected_data


def dt(X):
    for x in range(len(X)):
        X[x] = signal.detrend(X[x])
    return X

def sg(X):
    for x in range(len(X)):
        X[x] = signal.savgol_filter(X[x], 7, 3, mode="wrap")
    return X
# 最大最小值归一化
def mms(data):
    from sklearn.preprocessing import MinMaxScaler
    return MinMaxScaler().fit_transform(data)
def none(X):
    return X
class Preprocess:
    def __init__(self, method='none', **kwargs):
        self.method = method   if  not  isinstance(method,str) and hasattr(method, '__iter__') else [method]
        self.params = kwargs





    def transform(self, X):

        for m in self.method:
            m = m.lower()
            g = globals()
            if m in  g.keys():
                X = g[m](X)
            else:
                raise ValueError('Unsupported preprocess method.')
        return X



