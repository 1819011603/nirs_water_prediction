import pathlib
import numpy as np
from numpy import mat, zeros

def loadDataSet01(filename, Separator=', '):
    fr = open(filename)
    arrayLines = fr.readlines()
    assert len(arrayLines) != 0
    num = len(arrayLines[0].split(Separator)) - 1
    row = len(arrayLines)
    x = mat(zeros((row, num)))
    y = mat(zeros((row, 1)))
    index = 0
    for line in arrayLines:
        curLine = line.strip().split(Separator)
        curLine = [float(i) for i in curLine]
        x[index, :] = curLine[0: -1]
        # y[index, :] = curLine[-1]/100
        y[index, :] = curLine[-1]
        index += 1

    return np.array(x), np.array(y).ravel()


class Parameter:
    def __int__(self, optimal=False):
        self.optimal = optimal

para = Parameter()



# 预处理的算法的参数都是固定的
preprocess_args = {
    # "method":["SG","DT"]
    "method":["SG"]

    }

# 特征算法的参数设置
feature_selection_args = {

    "method":["cars","pca"],
    "pca":{
        # 主成分个数
        "n_components": 15,
    },
    "plsr":{
        "n_components":15,
    },
    "cars":{
        # cars的index
    "index": [3,5,8,14,26,31,41,43,48,49,53,59,65,72,80,81,85,87,90,110,111,116,120,122,126,127,128,153,158,175,180,184,197,198,202,205,206,214,227,240,241,255],
    },

    # 使用index的特征提取方法
    "index_set" : ["cars"],

}

# 模型的参数设置
model_args = {

    "model":"plsr",

    # svr
    "svr":{
        "C": 453,
        "gamma": 64,
        "kernel": "rbf",
    },


    # pls
    "plsr":{
        "n_components": 11,
    },
    "bpnn":{

        "hidden_layer_sizes": (15,),
        "activation" : 'logistic',
        "solver": 'adam',
        "alpha" : 0.0001,
        "learning_rate" : 'constant',
        "learning_rate_init" : 0.06,
                "power_t" :0.5,
        "max_iter" : 10000,
        "shuffle" : False,
        "tol" : 0.0001,
        "verbose" : False,
        "warm_start" :False,
        "momentum" : 0.9, "nesterovs_momentum" : True, "early_stopping" : False,
        "validation_fraction" : 0.1, "beta_1" : 0.937, "beta_2" : 0.999,
        "epsilon" :1e-08,

        "n_iter_no_change" : 10,
        "max_fun" : 15000

    },
    # SG+GT
    # "rbf":{'hidden_shape': 250, 'sigma': 22.19206269244502, 'alpha': 1480.8036479688653, 'kernel': 'gaussian', 'gamma': 0.07744522935425945},
    # SNV
    # "rbf": {'hidden_shape': 238, 'sigma': 210.55817241205375, 'alpha': 384.21457791907585, 'kernel': 'poly', 'gamma': 0.2616510138531062},
#     DT
    "rbf":{'hidden_shape': 255, 'sigma': 20.48862236375201, 'alpha': 128.6355374786053, 'kernel': 'gaussian', 'gamma': 0.8264571838644237}



}




X_test, y_test = loadDataSet01(pathlib.Path("./data/test.txt").absolute())
X_train, y_train = loadDataSet01(pathlib.Path("./data/train.txt").absolute())
