import pathlib

import numpy as np
from openpyxl import load_workbook
from nirs.parameters import*
def getDataIndex(x0, index):
    if len(index) == len(x0[0]):
        return x0
    index = np.array(index,copy=False)
    return x0[:,index]






def filter(x0,filter_method=None):
    x0 = np.array(x0,copy=True)
    for method in filter_method:
        x0 = method(x0)
    return x0


def save2excel(row, header, path='tmp.xlsx'):
    if para.path != None:
        path = para.path

    path = "./result/" + path

    create_excel(path)

    # 打开已有的Excel文件
    wb = load_workbook(filename=path)

    # 获取需要写入数据的sheet
    sheet = wb['Sheet']

    # 获取已有数据的最大行数
    max_row = sheet.max_row

    if max_row <= 1:
        sheet.append(header)
    sheet.append(row)

    wb.save(path)


def create_excel(path):
    import os
    from openpyxl import Workbook

    # 定义Excel文件路径
    file_path = path

    # 判断文件是否存在，不存在则创建
    if not os.path.exists(file_path):
        import pathlib
        file_dir = pathlib.Path(file_path).parent
        file_dir.mkdir(parents=True)



        # 创建一个新的Excel文件
        wb = Workbook()
        ws = wb.active
        # 保存Excel文件
        wb.save(os.path.abspath(file_path))
        print(f"{os.path.abspath(file_path)} created.")


def clear_excel(path):
    wb = load_workbook(filename=path)

    # 选择要清空的工作表
    ws = wb.active

    # 清空每个单元格的值
    for row in ws.iter_rows():
        for cell in row:
            cell.value = None

    # 删除所有的行和列
    ws.delete_cols(1, ws.max_column)
    ws.delete_rows(1, ws.max_row)

    # 保存修改后的xlsx文件
    wb.save(filename=path)